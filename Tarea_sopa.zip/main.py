"""
Programa principal
Generador de Sopa de Letras - Dr. House
"""

import utilidades
from utilidades.generador import crear_matriz, colocar_palabras, imprimir_matriz, imprimir_resuelta
from utilidades.colores import rojo


def ingresar_palabras():
   
    palabras = []

    while len(palabras) < 15:
        palabra = input("Ingrese una palabra (o escriba 'salir' para terminar): ")

        if palabra.lower() == "salir":
            break

        if palabra.isalpha():
            palabras.append(palabra)
        else:
            print("Solo se permiten letras.")

    return palabras


def menu():
    """
    Menu principal del programa.
    """
    palabras = ingresar_palabras()

    if not palabras:
        print("No se ingresaron palabras.")
        return

    tamano = 15
    matriz = utilidades.generador.crear_matriz(tamano)
    posiciones = utilidades.generador.colocar_palabras(matriz, palabras)

    while True:
        print("\n1. Mostrar sopa de letras")
        print("2. Resolver sopa de letras")
        print("3. Salir")

        opcion = input("Seleccione una opcion: ")

        if opcion == "1":
            utilidades.generador.imprimir_matriz(matriz)

        elif opcion == "2":
            utilidades.generador.imprimir_resuelta(matriz, posiciones, rojo)

        elif opcion == "3":
            print("Saliendo del programa...")
            break

        else:
            print("Opcion invalida.")


if __name__ == "__main__":
    menu()