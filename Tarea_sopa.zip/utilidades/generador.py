"""
Modulo generador
Contiene las funciones principales para crear, mostrar y resolver la sopa de letras.
"""

import random
import string


def crear_matriz(tamano):
    
    matriz = []
    for _ in range(tamano):
        fila = []
        for _ in range(tamano):
            fila.append(random.choice(string.ascii_uppercase))
        matriz.append(fila)
    return matriz


def colocar_palabras(matriz, palabras):
   
    posiciones = []

    tamano = len(matriz)

    for palabra in palabras:
        palabra = palabra.upper()
        fila = random.randint(0, tamano - 1)
        col = random.randint(0, tamano - len(palabra))

        for i in range(len(palabra)):
            matriz[fila][col + i] = palabra[i]

        posiciones.append((palabra, fila, col))

    return posiciones


def imprimir_matriz(matriz):
   
    for fila in matriz:
        print(" ".join(fila))


def imprimir_resuelta(matriz, posiciones, funcion_color):
    
    matriz_copia = [fila[:] for fila in matriz]

    for palabra, fila, col in posiciones:
        for i in range(len(palabra)):
            matriz_copia[fila][col + i] = funcion_color(matriz_copia[fila][col + i])

    for fila in matriz_copia:
        print(" ".join(fila))