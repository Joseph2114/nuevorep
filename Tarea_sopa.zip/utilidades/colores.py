"""
Modulo colores
Contiene funciones para imprimir texto con colores en consola usando codigos ANSI.
"""

def rojo(texto):
    """Retorna el texto en color rojo."""
    return "\033[31m" + texto + "\033[0m"

def verde(texto):
    """Retorna el texto en color verde."""
    return "\033[32m" + texto + "\033[0m"

def azul(texto):
    """Retorna el texto en color azul."""
    return "\033[34m" + texto + "\033[0m"